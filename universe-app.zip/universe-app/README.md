# 🌌 מגלי היקום — הוראות הפצה

## מה יש כאן
- `public/index.html` — האתר המלא, מותאם לטלפון ו-desktop
- כרגע שומר ב-localStorage (עובד אבל רק על המחשב שלך)
- עם Firebase → שמירה משותפת לכל העולם ✓

---

## שלב 1 — Vercel (בחינם, 3 דקות)

### א׳ — העלה את הקוד ל-GitHub
1. לך ל-[github.com](https://github.com) → "New repository" → שם: `universe-explorer`
2. "Create repository"
3. גרור את תיקיית `universe-app` לתוך הריפו או עשה:
```bash
cd universe-app
git init
git add .
git commit -m "🌌 universe explorer"
git remote add origin https://github.com/YOUR_USER/universe-explorer.git
git push -u origin main
```

### ב׳ — Deploy ל-Vercel
1. לך ל-[vercel.com](https://vercel.com) → "Sign up with GitHub"
2. "New Project" → בחר את `universe-explorer`
3. **Root Directory:** `public`
4. לחץ "Deploy"
5. תוך 30 שניות תקבל לינק כמו `universe-explorer-abc.vercel.app` ✓

---

## שלב 2 — Firebase (לשמירה משותפת לכולם)

### א׳ — צור Firebase project
1. לך ל-[console.firebase.google.com](https://console.firebase.google.com)
2. "Add project" → שם: `universe-explorer` → "Create project"
3. לחץ "Realtime Database" (בתפריט שמאל)
4. "Create Database" → בחר region → "Start in test mode"
5. העתק את ה-URL שנראה כך: `https://universe-explorer-XXXXX.firebaseio.com`

### ב׳ — חבר ל-index.html
פתח את `public/index.html`, מצא את השורה:
```js
const FIREBASE_URL = ''; // ← הכנס כאן
```
שנה ל:
```js
const FIREBASE_URL = 'https://universe-explorer-XXXXX.firebaseio.com';
```

### ג׳ — Redeploy ב-Vercel
Vercel מזהה אוטומטית כל push ל-GitHub ועושה deploy חדש.

---

## כללי Firebase Database
לאחר שהאתר עולה, לך ל-Firebase Console → Realtime Database → Rules, ושנה ל:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```
(לפיתוח בלבד — בהמשך אפשר להגדיר rules יותר מאובטחים)

---

## שיתוף
אחרי ה-deploy תקבל לינק קבוע. שלח אותו לכולם — כל לחיצה של כל אחד בעולם תצטבר ביחד.

---

## פתרון בעיות נפוצות

| בעיה | פתרון |
|------|--------|
| מסך לבן על טלפון | הגרסה החדשה משתמשת ב-CSS grid במקום canvas — אמורה לעבוד |
| הנתונים לא נשמרים | ודא שהכנסת את FIREBASE_URL נכון |
| Firebase error | ודא שה-Rules מוגדרות ל-test mode |

---

## עלות
- **Vercel:** חינם לחלוטין לפרויקט personal
- **Firebase:** חינם עד 1GB database + 10GB/month bandwidth — מספיק לאלפי משתמשים
